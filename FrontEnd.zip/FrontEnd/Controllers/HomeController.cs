﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Assignment4.Models;

namespace Assignment4.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index(string keywords)
        {
            if(keywords != null)
            {
                return RedirectToAction("SearchREsult", new { nextE = keywords });
            }
            return View();
        }
        
        [Route("[controller]/[action]")]
        public IActionResult SignIn(string username, string password)
        {
            return View();
        }
        
        [Route("[controller]/[action]")]
        public IActionResult Register(string email, string username, string password)
        {
            return View();
        }

        [HttpPost]
        public IActionResult AfterSignIn()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SearchREsult(string nextE)
        {
            return View();
        }
    }
}
