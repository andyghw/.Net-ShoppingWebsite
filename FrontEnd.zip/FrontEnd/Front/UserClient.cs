﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ShoppingWebsiteFront.Models;

namespace ShoppingWebsiteFront.Front
{
    public class UserClient
    {
        string _hostUri;
        public UserClient()
        {
            _hostUri = "https://localhost:63224";
        }

        HttpClient ShoppingWebsiteFront;
        public HttpClient CreateSingletonShoppingWebsiteFront()
        {
            if (ShoppingWebsiteFront == null)
            {
                ShoppingWebsiteFront = new HttpClient();
            }

            ShoppingWebsiteFront.BaseAddress = new Uri(new Uri(_hostUri), "api/products/");

            return ShoppingWebsiteFront;
        }

        public HttpClient CreateSingletonActionShoppingWebsiteFront(string action)
        {
            if (ShoppingWebsiteFront == null)
            {
                ShoppingWebsiteFront = new HttpClient();
            }

            ShoppingWebsiteFront.BaseAddress = new Uri(new Uri(_hostUri), "api/products/" + action);

            return ShoppingWebsiteFront;
        }

        public HttpClient CreateShoppingWebsiteFront()
        {
            ShoppingWebsiteFront = new HttpClient();
            ShoppingWebsiteFront.BaseAddress = new Uri(new Uri(_hostUri), "api/products/");
            return ShoppingWebsiteFront;
        }

        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            using (var client = CreateShoppingWebsiteFront())
            {
                HttpResponseMessage response;
                response = client.GetAsync(client.BaseAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    var avail = await response.Content.ReadAsStringAsync()
                        .ContinueWith<IEnumerable<Product>>(postTask =>
                        {
                            return JsonConvert.DeserializeObject<IEnumerable<Product>>(postTask.Result);
                        });
                    return avail;
                }
                else
                {
                    return null;
                }
            }
        }

        public async Task<IEnumerable<Product>> GetUsersAsync(string username, string password)
        {
            using (var client = CreateShoppingWebsiteFront())
            {
                HttpResponseMessage response;
                response = client.GetAsync(new Uri(client.BaseAddress, password, username)).Result;
                if (response.IsSuccessStatusCode)
                {
                    var avail = await response.Content.ReadAsStringAsync()
                        .ContinueWith<IEnumerable<Product>>(postTask =>
                        {
                            return JsonConvert.DeserializeObject<IEnumerable<Product>>(postTask.Result);
                        });
                    return avail;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
